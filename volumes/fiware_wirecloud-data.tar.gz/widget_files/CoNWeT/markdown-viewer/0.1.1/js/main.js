/*
 * markdown-viewer
 * https://github.com/mognom/markdown-viewer-widget
 *
 * Copyright (c) 2017 CoNWeT
 * Licensed under the Apache-2.0 license.
 */

/* globals MarkdownViewer */

window.onload = function () {
    "use strict";
    new MarkdownViewer();
};
