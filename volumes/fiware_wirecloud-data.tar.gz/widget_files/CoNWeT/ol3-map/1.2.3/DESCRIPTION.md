Map viewer widget using OpenLayers. It can receive Layers or Point of Interest data and display them
 on the map.