/*
 * markdown-editor
 * https://github.com/mognom/markdown-editor-widget
 *
 * Copyright (c) 2017 CoNWeT
 * Licensed under the Apache-2.0 license.
 */

/* globals MarkdownEditor */

window.onload = function () {
    "use strict";
    new MarkdownEditor();
};
