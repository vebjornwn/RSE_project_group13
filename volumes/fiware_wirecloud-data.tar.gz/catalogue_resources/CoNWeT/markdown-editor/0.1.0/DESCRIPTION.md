The Markdown editor widget is a WireCloud widget that provides the ability to edit markdown formatted text using WireCloud.
