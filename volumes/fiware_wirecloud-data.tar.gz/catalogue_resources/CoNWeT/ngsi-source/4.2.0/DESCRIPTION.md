This operator allows you to use any Orion Context Broker server as source of
data. This is accomplished by creating a subscription to obtain real time
notifications about changes on the entities of interest.

### References

* [Orion Context Broker info](http://catalogue.fiware.org/enablers/publishsubscribe-context-broker-orion-context-broker)
