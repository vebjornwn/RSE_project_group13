This mashup allows you to browse the offerings of a Business API Ecosystem marketplace and install/uninstall the components you have available.
