## Introduction

The BAE details widget is a WireCloud widget that provides the ability to displaye the details of an offering, such as the products, its pricing and the Wirecloud components it provides. Also, it  this widget allows to install or uninstall specifid Wirecloud components in an offering.

## Settings

-`Server URL`: The URL of the BAE server.

## Wiring

### Input Endpoints

-`Offering`: The offering whose details are to be displayed.

## Usage

This Widget its created and configured automatically by the [bae-browser-widget](https://github.com/Wirecloud/bae-browser-widget) so it doesnt need to be added to the dashboard when being used by it.

Send an offering with a complete productSpecification field to its input to display the offering's details.