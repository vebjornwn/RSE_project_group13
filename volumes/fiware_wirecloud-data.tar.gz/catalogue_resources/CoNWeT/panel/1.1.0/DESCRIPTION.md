Simple widget allowing you to display texts like measures (temperature, battery level, ...)
