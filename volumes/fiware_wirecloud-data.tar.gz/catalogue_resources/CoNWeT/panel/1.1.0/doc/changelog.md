## 1.1.0

- Add a preference for controlling how many decimals to use when displaying
  numbers

## 1.0.2

- Move to use pixel units for the initial size
- Change input endpoint friendcode to panel-content

## 1.0.1

- Added a max-height and a min-height preferences
- Round font-height values (improve text rendering)
- Added initial version of this changelog file and of the user guide

## 1.0.0

Initial version
