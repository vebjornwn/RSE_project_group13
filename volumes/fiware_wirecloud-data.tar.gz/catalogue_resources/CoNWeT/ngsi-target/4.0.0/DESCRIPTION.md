This operator allows you to use any Orion Context Broker server as target of
data. This operator uses normal HTTP requests to store data into the context
broker, so you don't need a NGSI proxy, but the context broker MUST support v2
of the API (v1 only support partial updates).

### References

* [Orion Context Broker info](http://catalogue.fiware.org/enablers/publishsubscribe-context-broker-orion-context-broker)
