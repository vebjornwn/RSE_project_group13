## v0.1.1 (2017-09-06)

Initial version

- Remove market info.
- Fix documentation.
