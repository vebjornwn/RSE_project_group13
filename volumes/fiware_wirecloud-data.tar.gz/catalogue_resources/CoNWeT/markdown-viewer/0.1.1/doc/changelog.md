## v0.1.1

- Improved style.

## v0.1.0

Initial markdown-viewer widget release