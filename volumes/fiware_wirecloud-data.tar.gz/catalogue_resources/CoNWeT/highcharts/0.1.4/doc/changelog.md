## v0.1.4 (2019-05-21)

Minor bug fix release.


## v0.1.3 (2018-11-26)

- Upgraded to Highcharts 6.2.0
- Add support for solid gauge charts.

## v0.1.2 (2016-11-30)

- Fix added the feature of opening Highcharts credits on a new tab.

## v0.1.1 (2016-11-29)

- Upgraded to Highcharts 5.0.2
- Added experimental support for object event payloads on the wiring input
 endpoints.
- Added experimental support for displaying messages inside the widget using
 events.
- Open Highcharts credits in a new tab.

> **NOTE**: This version has a bug, don't use it.

## v0.1.0

Initial version
