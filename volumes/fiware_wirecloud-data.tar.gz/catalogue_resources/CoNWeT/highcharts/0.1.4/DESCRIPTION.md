This widget allows you to show great and dynamic charts using the
[Highcharts](http://www.highcharts.com/) framework.

> **NOTE**: Take into account that Highcharts is **free for non-commercial**.
> If you want to use Highcharts for a personal website, a school site or a
> non-profit organisation? Then you don't need the author's permission, just go
> on and use this widget. For commercial websites and projects, see
> [License and Pricing](http://shop.highsoft.com/highcharts.html).
