このウィジェットでは、利用可能なワークスペースをブラウズして
見つけることができます。

## リファレンス

[WireCloud](https://github.com/Wirecloud/wirecloud)
