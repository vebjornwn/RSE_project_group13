## Introduction

This widget allows you to browse and discover the available
workspaces/dashboards.

## Settings

This widget has no settings

## Wiring

### Input Endpoints

- This widget has no input endpoint

### Output Endpoints

- This widget has no output endpoint

