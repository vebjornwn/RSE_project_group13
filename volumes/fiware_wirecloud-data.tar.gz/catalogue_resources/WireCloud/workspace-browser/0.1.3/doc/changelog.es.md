## v0.1.3 (2019/05/23)

- Añadido soporte para internacionalización (i18n)
- Añadida la traducción al Japonés
- Añadida la traducción al Español


## v0.1.2 (2017/10/20)

- Use the title metadata to list workspaces. This change requires WireCloud
  v1.1+
- Improved documentation

## v0.1.1

- Remove visibility and owner filter buttons when running as an anonymous user
- Fix problems moving between the different pages
- Use different icons depending if the workspace is privated, shared or public

## v0.1.0

Initial version
