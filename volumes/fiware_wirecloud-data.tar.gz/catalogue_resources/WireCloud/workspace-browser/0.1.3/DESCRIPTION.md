This widget allows you to browse and discover the available
workspaces/dashboards.

## References

[WireCloud](https://github.com/Wirecloud/wirecloud)
